/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable react-hooks/set-state-in-effect */
import { useEffect, useMemo, useRef, useState } from "react";
import { motion, PanInfo, useMotionValue, useTransform } from "motion/react";
import React, { JSX } from "react";

// replace icons with your own if needed
import Image from "next/image";
import { AiFillStar } from "react-icons/ai";
//! import TypingEffect from "./TypingEffect";
export interface CarouselItem {
  id: number;
  title?: string;
  description?: string;
  icon?: React.ReactNode;
  image?: string;
  video?: string;
}

export interface CarouselProps {
  items?: CarouselItem[];
  baseWidth?: number;
  autoplay?: boolean;
  autoplayDelay?: number;
  pauseOnHover?: boolean;
  loop?: boolean;
  round?: boolean;
  variant?: CarouselVariant;
}

type CarouselVariant = "review" | "media";

export const DEFAULT_ITEMS: CarouselItem[] = [
  {
    id: 1,
    title: "Aditi Sharma",
    description:
      "Loved the quality and fit. Delivery was faster than expected.",
    icon: (
      <div className="flex gap-5 w-full justify-center">
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
      </div>
    ),
    image: "/Assets/Images/Profiles/profile.jpg",
  },
  {
    id: 2,
    title: "Rahul Verma",
    description: "Great designs and premium feel. Worth the price. ",
    icon: (
      <div className="flex gap-5 w-full justify-center">
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
      </div>
    ),
    image: "/Assets/Images/Profiles/profile.jpg",
  },
  {
    id: 3,
    title: "Neha Gupta",
    description: "Customer support was very helpful. Will order again.",
    icon: (
      <div className="flex gap-5 w-full justify-center">
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
      </div>
    ),
    image: "/Assets/Images/Profiles/profile.jpg",
  },
  {
    id: 4,
    title: "Arjun Singh",
    description: "Nice collection, especially the winter wear.",
    icon: (
      <div className="flex gap-5 w-full justify-center">
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
      </div>
    ),
    image: "/Assets/Images/Profiles/profile.jpg",
  },
  {
    id: 5,
    title: "Sneha Patel",
    description: "Fabric quality exceeded my expectations.",
    icon: (
      <div className="flex gap-5 w-full justify-center">
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
        <AiFillStar className="h-4 w-4 text-yellow-400" />
      </div>
    ),
    image: "/Assets/Images/Profiles/profile.jpg",
  },
];

const DRAG_BUFFER = 0;
const VELOCITY_THRESHOLD = 500;
const GAP = 16;
const SPRING_OPTIONS = { type: "spring" as const, stiffness: 300, damping: 30 };

interface CarouselItemProps {
  item: CarouselItem;
  index: number;
  itemWidth: number;
  round: boolean;
  trackItemOffset: number;
  x: any;
  transition: any;
  variant: CarouselVariant;
}

function CarouselItem({
  item,
  index,
  itemWidth,
  round,
  trackItemOffset,
  x,
  transition,
  variant,
}: CarouselItemProps) {
  const range = [
    -(index + 1) * trackItemOffset,
    -index * trackItemOffset,
    -(index - 1) * trackItemOffset,
  ];
  const outputRange = [90, 0, -90];
  const rotateY = useTransform(x, range, outputRange, { clamp: false });

  return (
    <motion.div
      key={`${item?.id ?? index}-${index}`}
      className={`relative shrink-0 flex flex-col ${
        round
          ? "items-center justify-center text-center bg-[#060010] border-0"
          : "items-start justify-between bg-[#000000cf] border border-[#222] rounded-xl"
      } overflow-hidden cursor-grab active:cursor-grabbing`}
      style={{
        width: itemWidth,
        height: round ? itemWidth : "100 %",
        rotateY: rotateY,
        ...(round && { borderRadius: "50%" }),
      }}
      transition={transition}
    >
      <div className="flex sm:flex-row flex-col w-full h-full">
        {variant === "review" && (
          <div
            className={`${round ? "p-0 m-0" : "mb-4 p-5 w-full md:w-[48%] lg:w-[48%] lg:h-[30%]"}`}
          >
            <span className="flex h-[4vh] w-full items-center justify-center rounded-full bg-[#060010]">
              {item.icon}
            </span>
          </div>
        )}
        {variant === "media" && item.video ? (
          <div className="relative overflow-hidden rounded-xl w-full h-[75vh] bg-black">
            <video
              src={item.video}
              className="w-full h-full"
              autoPlay
              muted
              loop
              playsInline
              preload="none"
            />
          </div>
        ) : item.image ? (
          <div className="relative mx-auto overflow-hidden m-2 rounded-4xl w-[80%] md:w-[48%] lg:w-[48%] h-[30vh] bg-black">
            <Image
              fill
              src={item.image}
              alt={item.title || "carousel item"}
              className="object-cover"
            />
          </div>
        ) : null}
      </div>
      {variant === "review" && (
        <div className="md:p-10 lg:p-10 p-5 h-[65%] w-full text-start">
          <div className="mb-1 font-black text-lg text-white">{item.title}</div>
          <div className="text-sm text-white">
            {item.description || ""}
          </div>
        </div>
      )}
    </motion.div>
  );
}

export default function Carousel({
  items = DEFAULT_ITEMS,
  baseWidth = 300,
  autoplay = false,
  autoplayDelay = 3000,
  pauseOnHover = true,
  loop = false,
  round = false,
  variant = "review",
}: CarouselProps): JSX.Element {
  const containerPadding = 16;
  const itemWidth = baseWidth - containerPadding * 2;
  const trackItemOffset = itemWidth + GAP;
  const itemsForRender = useMemo(() => {
    if (!loop) return items;
    if (items.length === 0) return [];
    return [items[items.length - 1], ...items, items[0]];
  }, [items, loop]);

  const [position, setPosition] = useState<number>(loop ? 1 : 0);
  const x = useMotionValue(0);
  const [isHovered, setIsHovered] = useState<boolean>(false);
  const [isJumping, setIsJumping] = useState<boolean>(false);
  const [isAnimating, setIsAnimating] = useState<boolean>(false);

  const containerRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (pauseOnHover && containerRef.current) {
      const container = containerRef.current;
      const handleMouseEnter = () => setIsHovered(true);
      const handleMouseLeave = () => setIsHovered(false);
      container.addEventListener("mouseenter", handleMouseEnter);
      container.addEventListener("mouseleave", handleMouseLeave);
      return () => {
        container.removeEventListener("mouseenter", handleMouseEnter);
        container.removeEventListener("mouseleave", handleMouseLeave);
      };
    }
  }, [pauseOnHover]);

  useEffect(() => {
    if (!autoplay || itemsForRender.length <= 1) return undefined;
    if (pauseOnHover && isHovered) return undefined;

    const timer = setInterval(() => {
      setPosition((prev) => Math.min(prev + 1, itemsForRender.length - 1));
    }, autoplayDelay);

    return () => clearInterval(timer);
  }, [autoplay, autoplayDelay, isHovered, pauseOnHover, itemsForRender.length]);

  useEffect(() => {
    const startingPosition = loop ? 1 : 0;
    setPosition(startingPosition);
    x.set(-startingPosition * trackItemOffset);
  }, [items.length, loop, trackItemOffset, x]);

  useEffect(() => {
    if (!loop && position > itemsForRender.length - 1) {
      setPosition(Math.max(0, itemsForRender.length - 1));
    }
  }, [itemsForRender.length, loop, position]);

  const effectiveTransition = isJumping ? { duration: 0 } : SPRING_OPTIONS;

  const handleAnimationStart = () => {
    setIsAnimating(true);
  };

  const handleAnimationComplete = () => {
    if (!loop || itemsForRender.length <= 1) {
      setIsAnimating(false);
      return;
    }
    const lastCloneIndex = itemsForRender.length - 1;

    if (position === lastCloneIndex) {
      setIsJumping(true);
      const target = 1;
      setPosition(target);
      x.set(-target * trackItemOffset);
      requestAnimationFrame(() => {
        setIsJumping(false);
        setIsAnimating(false);
      });
      return;
    }

    if (position === 0) {
      setIsJumping(true);
      const target = items.length;
      setPosition(target);
      x.set(-target * trackItemOffset);
      requestAnimationFrame(() => {
        setIsJumping(false);
        setIsAnimating(false);
      });
      return;
    }

    setIsAnimating(false);
  };

  const handleDragEnd = (
    _: MouseEvent | TouchEvent | PointerEvent,
    info: PanInfo,
  ): void => {
    const { offset, velocity } = info;
    const direction =
      offset.x < -DRAG_BUFFER || velocity.x < -VELOCITY_THRESHOLD
        ? 1
        : offset.x > DRAG_BUFFER || velocity.x > VELOCITY_THRESHOLD
          ? -1
          : 0;

    if (direction === 0) return;

    setPosition((prev) => {
      const next = prev + direction;
      const max = itemsForRender.length - 1;
      return Math.max(0, Math.min(next, max));
    });
  };

  const dragProps = loop
    ? {}
    : {
        dragConstraints: {
          left: -trackItemOffset * Math.max(itemsForRender.length - 1, 0),
          right: 0,
        },
      };

  const activeIndex =
    items.length === 0
      ? 0
      : loop
        ? (position - 1 + items.length) % items.length
        : Math.min(position, items.length - 1);

  return (
    <div
      ref={containerRef}
      className={`relative overflow-hidden ${variant !== "media" && "h-120"} p-4 ${
        round ? "rounded-full border border-white" : "rounded-4xl "
      }`}
      style={{
        width: `${baseWidth}px`,
        ...(round && { height: `${baseWidth}px` }),
      }}
    >
      <motion.div
        className="flex h-[95%] "
        drag={isAnimating ? false : variant === "media" ? false : "x"}
        {...dragProps}
        style={{
          width: itemWidth,
          gap: `${GAP}px`,
          perspective: 1000,
          perspectiveOrigin: `${position * trackItemOffset + itemWidth / 2}px 50%`,
          x,
        }}
        onDragEnd={handleDragEnd}
        animate={{ x: -(position * trackItemOffset) }}
        transition={effectiveTransition}
        onAnimationStart={handleAnimationStart}
        onAnimationComplete={handleAnimationComplete}
      >
        {itemsForRender.map((item, index) => (
          <CarouselItem
            key={`${item?.id ?? index}-${index}`}
            item={item}
            index={index}
            itemWidth={itemWidth}
            round={round}
            trackItemOffset={trackItemOffset}
            x={x}
            transition={effectiveTransition}
            variant={variant}
          />
        ))}
      </motion.div>
      {variant === "review" && (<div
        className={`flex w-full justify-center ${round ? "absolute z-20 bottom-12 left-1/2 -translate-x-1/2" : ""}`}
      >
        <div className="mt-4 flex w-37.5 justify-between px-8">
          {items.map((_, index) => (
            <motion.div
              key={index}
              className={`h-2 w-2 rounded-full cursor-pointer transition-colors duration-150 ${
                activeIndex === index
                  ? round
                    ? "bg-white"
                    : "bg-[#333333]"
                  : round
                    ? "bg-[#555]"
                    : "bg-[rgba(51,51,51,0.4)]"
              }`}
              animate={{
                scale: activeIndex === index ? 1.2 : 1,
              }}
              onClick={() => setPosition(loop ? index + 1 : index)}
              transition={{ duration: 0.15 }}
            />
          ))}
        </div>
      </div>)}
    </div>
  );
}
