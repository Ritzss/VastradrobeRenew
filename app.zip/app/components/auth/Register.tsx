"use client";
import { useAppContext } from "@/hooks/useAppContext";
import { EyeClosedIcon, EyeIcon } from "lucide-react";
import Image from "next/image";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import React, { useState } from "react";

const Register = () => {
  const [visible, setVisible] = useState(false);
  const { registerForm, setRegisterForm, handleRegister} = useAppContext();
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    setRegisterForm((prev: any) => ({ ...prev, [name]: value }));
  };

   const router = useRouter();
    const searchParams = useSearchParams();
  
    const redirectTo = searchParams.get("redirect") || "/";
    const safeRedirect = redirectTo.startsWith("/") ? redirectTo : "/";
  
    const onSubmit = async (e: React.FormEvent) => {
      const success = await handleRegister(e);
      
      if (success){
      router.replace(safeRedirect);
    }
    };


 
  return (
    <section className="md:w-[80%] my-4 w-full md:m-20 overflow-hidden rounded-xl border md:h-[70vh] md:flex">
      <aside className="md:w-[40%] h-auto text-[#ffffff] shadow-[inset_0_0_20px_#cd0000] md:border-r-4 flex-col flex justify-between">
        <header className="flex-col flex gap-5">
          <div className="font-sans text-[#cd0000] pt-6 text-4xl flex justify-center hover:scale-115 hover:text-shadow-[0_0_10px] font-bold text-shadow-[0_0_20px] duration-500 transition-all">
            Register
          </div>
        <div className="text-[#cd0000] p-2.5 text-xl font-great flex justify-start">
            It&apos;s look like you found yourself to a brand new Fashion hub.
            <br />
            <br />
            Register to begin you new Journey with Us.
          </div>
        </header>
        <div className="overflow-hidden self-end">
          <Image
            src={"https://res.cloudinary.com/dwhn5ec09/image/upload/v1771933083/authimg_unlbxi.png"}
            width={300}
            height={2}
            alt=""
            priority
            className="w-83 h-50"
          />
        </div>
      </aside>
      <aside className="md:w-[60%] h-auto font-sans text-white shadow-[inset_0_0_150px_28px_#cd0000] flex flex-col justify-center items-center ">
        <form
        onSubmit={onSubmit}
          className="flex flex-col justify-evenly w-full h-90 p-4 "
        >
          <label className="flex justify-between" htmlFor="LoginID">
            <div className=" w-[40%] text-xl">UserName:</div>
            <div className="border-b w-[65%]">
              <input
                type="text"
                name="username"
                value={registerForm.username}
                onChange={handleInputChange}
                placeholder="UserName"
                id="Username"
                className="outline-0 flex items-center w-full"
              />
            </div>
          </label>
          <label className="flex justify-between" htmlFor="LoginID">
            <div className=" w-[40%] text-xl">Email:</div>
            <div className="border-b w-[65%]">
              <input
                type="text"
                name="email"
                value={registerForm.email}
                onChange={handleInputChange}
                placeholder="Email"
                id="LoginID"
                className="outline-0 flex items-center w-full"
              />
            </div>
          </label>
          <label className="flex justify-between" htmlFor="LoginPassword">
            <div className="w-[40%] text-xl">Password:</div>
            <div className="border-b flex w-[65%]">
              <input
                type={visible ? "text" : "password"}
                name="password"
                value={registerForm.password}
                onChange={handleInputChange}
                placeholder="Password"
                id="LoginPassword"
                className="outline-0 flex items-center w-[90%]"
              />
              <div
                className={`w-[10%] flex justify-center rounded-r `}
                onClick={() => setVisible(!visible)}
              >
                {visible ? (
                  <EyeIcon className="w-[50%] " />
                ) : (
                  <EyeClosedIcon className="w-[50%] " />
                )}
              </div>
            </div>
          </label>
          <div className="flex justify-evenly">
            <button type="submit" className="text-2xl hover:text-[#ffffff] duration-500 transition-all hover:text-shadow-[0px_16px_5px_rgba(0,0,0,0.34)]">
              Register
            </button>
          </div>
        </form>
        <footer className="h-[40%] flex md:flex-row flex-col md:justify-between justify-center items-center w-full p-1 gap-1">
          <div>Havn&apos;t we met before? <Link href={"login"} className="hover:underline hover:text-[#0092d6] duration-500 transition-all">Login</Link></div>
          <div className=""><Link href={"reset_password"} className="hover:underline hover:text-[#0092d6] duration-500 transition-all">Forgot Password</Link>?Don&apos;t restart</div>
        </footer>
      </aside>
    </section>
  );
};

export default Register;
